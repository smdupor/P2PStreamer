#!/bin/sh

# sets up iptables firewall on NCSU VCL for TA Testing

sudo iptables -I INPUT -p tcp --dport 65432:65450 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
sudo iptables -I OUTPUT -p tcp --dport 65432:65450 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
